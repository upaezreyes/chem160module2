import random, math   # two modules in one import

inside = 0  # darts inside the circle
ntrials = 1000000  # total number of darts trown to the dartboard


for i in range(ntrials):
    x = random.random()   # picking random positions at x
    y = random.random()   # picking random positions at y
    if (x*x+y*y) < 1.0:
        # points are inside the circle, the radius is 1
        inside += 1   # same as inside = inside + 1
pi = 4.*inside/ntrials   # 4x(number of darts inside/ntrials)
print("N=%d Error=%8.5f "%(ntrials, pi-math.pi))