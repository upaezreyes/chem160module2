from random import choice
ntrials = 1000   # number of trials
nsteps = 10000  # numbe of steps
got_home = 0   # initial position (square 0)

for i in range(ntrials):
    point = 0
    for step in range(nsteps):
        point += choice((-1,1))   # adding each step it takes
        if point == 0 :
            got_home += 1
            break
print("Fraction that got home=", got_home/ntrials)