
from random import choices  # getting choices from libraries
ntrials = 1000000
limit = 1000
count = 0

for i in range(ntrials):
    rand = choices(range(1, limit+1), k=3)  # from 1 to 100, pick 3 numbers
    if rand[0] + rand[1] <= rand[2]:
        count = count+1
print("Fraction=", count/ntrials)
