from random import choices
nrolls = 10000   # number of rolls
total = 0     # to keep track of the total nrolls
ndice =20  #  number of dices

for i in range(nrolls):
    dice = choices(range(1, 7), k=ndice)  #chooses two number(ndice) randomly
    dice.sort(reverse=True)    # sort the numbers from high to low
    total = total + dice[0] + dice[1]  # adding the two picked numbers

print("Average roll=", total/nrolls)    # calculates the avg sum